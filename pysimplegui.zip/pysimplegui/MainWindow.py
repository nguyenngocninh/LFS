import PySimpleGUI as sg
import ctypes
def show():
    print("学習機能")
def show1():
    print("世代管理")
def show2():
    print("アプリ情報")

layout_column_button=[[sg.Button("学習機能", key = show, button_color= "#E0EFF9", image_filename="./button.png",
         border_width = 0, font=("Helvetica", 16, "bold"), pad = (0,0))],
         [sg.Button("世代管理", key = show1, button_color= "#E0EFF9",image_filename="./button.png",
         border_width = 0, font=("Helvetica", 16, "bold"), pad = (0,15))]]

layout_column_logo = [[sg.Image(filename='./tem1.png', key='tem')]]

layouttrain = [[sg.Image(filename='./tem.png', key='tem1')]]

layout = [[sg.Column(layouttrain, key = "train", visible= False)],[sg.Column(layout_column_logo, key = "logo", background_color="#E0EFF9", expand_x= True, expand_y= True), 
sg.Column(layout_column_button,key = "button", background_color="#E0EFF9", expand_x= True, expand_y= True, pad=(30,90))], 
[sg.Button("アプリ情報", key = show2, button_color= ("black","#87C0FF"),font=("Helvetica", 10), pad = ((725,0),(0,0)))]]

window = sg.Window("AI学習プラットフォーム",layout,background_color="#E0EFF9", border_depth = 0,size =(838,490))


while True:
    event, values = window.read()
    if callable(event):
        window["logo"].update(visible = False)     
        window["button"].update(visible = False)
        window[show2].update(visible = False)
        #window["train"].update(visible = True)
    elif event in (sg.WIN_CLOSED, "Exit"):
        break
window.close()
