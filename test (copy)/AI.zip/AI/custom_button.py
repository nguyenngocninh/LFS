import tkinter as tk
from tkinter_custom_button import TkinterCustomButton                  


    
root = tk.Tk()
tk.TkinterCustomButton(root, 
          text='Choose Color', 
          fg="darkgreen", corner_radius=10).pack(side=tk.LEFT, padx=10)
tk.mainloop()