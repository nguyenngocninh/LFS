from tkinter import * 
import tkinter as tk
from tkinter.ttk import *
from PIL import Image
from PIL import ImageTk

class Example(Frame):
    def __init__(self, parent):
        Frame.__init__(self, parent)
        
        self.parent = parent
        self.openMainWindow()
    
    def openMainWindow(self):
        global photoImg
        self.pack(fill = BOTH,expand=1)
        #self.configure(bg='#E0EFF9')
        img = Image.open("./123.png")
        img = img.resize((210,48), Image.ANTIALIAS)
        photoImg =  ImageTk.PhotoImage(img)


        buttonDataset= tk.Button(self, text = "           Dataset Management" ,image = photoImg,
                                                fg="white", font=("",9,"bold"),compound = CENTER, height=35, width=180)
        buttonDataset.pack(side = TOP, anchor = 'ne',padx=30,pady=40) 

root = Tk()
root.geometry("250x150+300+300")
app = Example(root)
root.mainloop()