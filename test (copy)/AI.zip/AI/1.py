# importing only those functions 
# which are needed 
from tkinter import * 
import tkinter as tk
from tkinter.ttk import *
from PIL import Image
from PIL import ImageTk

def openMainWindow(root):
    global photoImg
    global gui_elements
    root.configure(bg='#E0EFF9')
    frame = tk.Frame(root,bg='#E0EFF9')
    frame.pack(side = LEFT,fill=BOTH, expand=True)


    load = Image.open("./4x.PNG")
    load = load.resize((300,350), Image.ANTIALIAS)
    render = ImageTk.PhotoImage(load)

    img0 = tk.Label(frame, image=render,bg='#E0EFF9')
    img0.image = render
    img0.pack(fill=BOTH, expand=True)



    img = Image.open("./123.png")
    img = img.resize((210,48), Image.ANTIALIAS)
    photoImg =  ImageTk.PhotoImage(img)


    buttonDataset= tk.Button(root, text = "           Dataset Management" ,image = photoImg,
                                            fg="white", font=("",9,"bold"),compound = CENTER, height=35, width=180)
    buttonDataset.pack(side = TOP, anchor = 'ne',padx=30,pady=40) 

    buttonTransLearning = tk.Button(root, text = "        Transfer Learning" ,image = photoImg,
                              fg="white", font=("",9,"bold"),compound = CENTER, height=35, width=180)
    buttonTransLearning.pack(side = TOP, anchor = 'ne',padx=30) 

    buttonTraniedModel= tk.Button(root, text = "      Trained Model\n      Management" ,image = photoImg,
                        fg="white", font=("",9,"bold"),compound = CENTER, height=35, width=180)
    buttonTraniedModel.pack(side = TOP, anchor = 'ne',padx=30,pady=40) 

    gui_elements0 = [frame,img0,
                             buttonDataset,
                             buttonTransLearning,
                             buttonTraniedModel]
    buttonTransLearning['command'] = lambda gui_elements=gui_elements0 : go_to_transferLearning(gui_elements)




def openLearningWindow(root): 

  
    # sets the title of the 
    # Toplevel widget 
    root.title("Transfer Learning") 

    # sets the geometry of toplevel 

    root.configure(bg='#C3E0FF')

    menubar = tk.Menu(root,bg='#FEEAD4', font=("",9,"bold") )

    objectDetection = Menu(menubar, tearoff=0, bg='white')
    objectDetection.add_command(label="Train")
    objectDetection.add_command(label="Evaluate")
    objectDetection.add_command(label="Interference")
    objectDetection.add_command(label="Prune")

    menubar.add_cascade(label="ObjectDetection", menu=objectDetection)

    Segmentation = Menu(menubar, tearoff=0, bg='white')
    Segmentation.add_command(label="Train")
    Segmentation.add_command(label="Evaluate")
    Segmentation.add_command(label="Interference")
    Segmentation.add_command(label="Prune")

    menubar.add_cascade(label="Segmentation", menu=Segmentation)

    root.config(menu=menubar)


    buttonBackMain= tk.Button(root, text = "Back",bg='#FEEAD4')
    buttonBackMain.pack(side = TOP, anchor = 'nw',padx=10,pady=10) 


    load = Image.open("./5x.PNG")
    load = load.resize((216,250), Image.ANTIALIAS)
    render = ImageTk.PhotoImage(load)

    img0 = tk.Label(root, image=render,bg='#C3E0FF')
    img0.image = render
    img0.pack(fill= Y,side = LEFT, anchor = 'nw',padx=40,pady=40)

    load = Image.open("./6x.PNG")
    load = load.resize((216,250), Image.ANTIALIAS)
    render = ImageTk.PhotoImage(load)

    img1 = tk.Label(root, image=render,bg='#C3E0FF')
    img1.image = render
    img1.pack(fill= Y,side = RIGHT, anchor = 'ne',padx=40,pady=40)

    gui_elements1 = [menubar,
                             buttonBackMain,img0,img1]
    buttonBackMain['command'] = lambda gui_elements=gui_elements1 : back_to_main(gui_elements)



def gui_elements_remove(elements):
    for element in elements:
        element.destroy()

def back_to_main(gui_elements):
    gui_elements_remove(gui_elements)
    openMainWindow(root)

def go_to_transferLearning(gui_elements):
    gui_elements_remove(gui_elements)
    openLearningWindow(root)


def main():
    global root

    root = tk.Tk() 
    root.title("AI Learning Platform") 

    root.geometry("600x350")

    openMainWindow(root)
    root.mainloop()

if __name__ == '__main__':
    main()