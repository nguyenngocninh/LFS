# importing only those functions 
# which are needed 
from tkinter import * 
import tkinter as tk
from tkinter.ttk import *
from PIL import Image
from PIL import ImageTk

# creating tkinter window 
root = tk.Tk() 
root.geometry("600x350")

root.configure(bg='#e4f9fc')

img2 = Label(root, text="AI Learning Platform")
img2.pack(side = TOP, anchor = 'nw',padx=20,pady=20)

load = Image.open("./12.jpg")
load = load.resize((147,128), Image.ANTIALIAS)
render = ImageTk.PhotoImage(load)

#img1 = Label(root, image=render)
#img1.image = render
#img1.pack(side = TOP, anchor = 'nw',padx=50,pady=60)
#
img = Image.open("./123.png")
img = img.resize((210,48), Image.ANTIALIAS)
photoImg =  ImageTk.PhotoImage(img)


buttonExample1= tk.Button(root, text = "           Dataset Management" ,image = photoImg,
                    compound = CENTER, height=40, width=190)
buttonExample1.pack(side = TOP, anchor = 'ne',padx=20,pady=40) 

buttonExample2= tk.Button(root, text = "        Transfer Learning" ,image = photoImg,
                    compound = CENTER, height=40, width=190)
buttonExample2.pack(side = TOP, anchor = 'ne',padx=20) 

buttonExample3= tk.Button(root, text = "      Trained Model\n      Management" ,image = photoImg,
                    compound = CENTER, height=40, width=190)
buttonExample3.pack(side = TOP, anchor = 'ne',padx=20,pady=40) 



root.mainloop() 