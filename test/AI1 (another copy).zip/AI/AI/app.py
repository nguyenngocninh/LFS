# importing only those functions 
# which are needed 
from tkinter import * 
import tkinter as tk
from tkinter.ttk import *
from PIL import Image
from PIL import ImageTk

def openLearningWindow(root1): 
      
    # Toplevel object which will  
    # be treated as a new window 
    learningWindow = Toplevel(root1) 
  
    # sets the title of the 
    # Toplevel widget 
    learningWindow.title("Transfer Learning") 
  
    # sets the geometry of toplevel 
    learningWindow.geometry("600x350") 

    learningWindow.configure(bg='#C3E0FF')

    menubar = tk.Menu(learningWindow,bg='#FEEAD4', font=("",9,"bold") )

    objectDetection = Menu(menubar, tearoff=0, bg='white')
    objectDetection.add_command(label="Train")
    objectDetection.add_command(label="Evaluate")
    objectDetection.add_command(label="Interference")
    objectDetection.add_command(label="Prune")

    menubar.add_cascade(label="ObjectDetection", menu=objectDetection)

    Segmentation = Menu(menubar, tearoff=0, bg='white')
    Segmentation.add_command(label="Train")
    Segmentation.add_command(label="Evaluate")
    Segmentation.add_command(label="Interference")
    Segmentation.add_command(label="Prune")

    menubar.add_cascade(label="Segmentation", menu=Segmentation)

    learningWindow.config(menu=menubar)

    load = Image.open("./5x.PNG")
    load = load.resize((216,250), Image.ANTIALIAS)
    render = ImageTk.PhotoImage(load)

    img0 = tk.Label(learningWindow, image=render,bg='#C3E0FF')
    img0.image = render
    img0.pack(fill= Y,side = LEFT, anchor = 'nw',padx=40,pady=40)

    load = Image.open("./6x.PNG")
    load = load.resize((216,250), Image.ANTIALIAS)
    render = ImageTk.PhotoImage(load)

    img0 = tk.Label(learningWindow, image=render,bg='#C3E0FF')
    img0.image = render
    img0.pack(fill= Y,side = RIGHT, anchor = 'ne',padx=40,pady=40)


# creating tkinter window 
root = tk.Tk() 
root.title("AI Learning Platform") 

root.geometry("600x350")

root.configure(bg='#E0EFF9')


frame = tk.Frame(root,bg='#E0EFF9')
frame.pack(side = LEFT,fill=BOTH, expand=True)


load = Image.open("./4x.PNG")
load = load.resize((300,350), Image.ANTIALIAS)
render = ImageTk.PhotoImage(load)

img0 = tk.Label(frame, image=render,bg='#E0EFF9')
img0.image = render
img0.pack(fill=BOTH, expand=True)



img = Image.open("./123.png")
img = img.resize((210,48), Image.ANTIALIAS)
photoImg =  ImageTk.PhotoImage(img)


buttonDataset= tk.Button(root, text = "           Dataset Management" ,image = photoImg,
                                        fg="white", font=("",9,"bold"),compound = CENTER, height=35, width=180)
buttonDataset.pack(side = TOP, anchor = 'ne',padx=30,pady=40) 

buttonTransLearning = tk.Button(root, text = "        Transfer Learning" ,image = photoImg,
                          fg="white", font=("",9,"bold"),compound = CENTER, height=35, width=180)
buttonTransLearning.pack(side = TOP, anchor = 'ne',padx=30) 

buttonTransLearning['command'] = lambda root1=root : openLearningWindow(root1)

buttonTraniedModel= tk.Button(root, text = "      Trained Model\n      Management" ,image = photoImg,
                    fg="white", font=("",9,"bold"),compound = CENTER, height=35, width=180)
buttonTraniedModel.pack(side = TOP, anchor = 'ne',padx=30,pady=40) 

root.mainloop() 