from tkinter import * 
import tkinter as tk
from tkinter.ttk import *
from PIL import Image
from PIL import ImageTk

import MainWindow

class TrainedModel(tk.Frame): 
	def __init__(self, parent, controller):
		tk.Frame.__init__(self,parent)
		self.parent = parent

		frame0 = tk.Frame(self,bg='#C3E0FF')
		frame0.pack(fill=X)
  	
		lbl0 = tk.Label(frame0, text="Model information",font =("",10,'bold'), bg='#C3E0FF')
		lbl0.pack(side=LEFT, padx=30, pady=10)

		frame5 = tk.Frame(self, bg='#C3E0FF')
		frame5.pack(side = BOTTOM,fill=BOTH, expand = True)

		buttonBackMain= tk.Button(frame5, text = "Back")
		buttonBackMain.pack(side = BOTTOM, anchor = 'sw',padx=10,pady=10) 
		buttonBackMain['command'] = lambda: controller.show_frame(MainWindow.MainWindow)	

	def CreateMenuBar(self,controller):

			menubar = tk.Menu(controller,bg='#FEEAD4', font=("",9,"bold") )
	
			menubar.add_command(label="Clone", command = self.CloneRepo)

			menubar.add_command(label="Checkout",command = self.CheckoutBranch)

			menubar.add_command(label="Push", command = self.PushData)

			return menubar

	def CloneRepo(self):
		print("CloneRepo")

	def CheckoutBranch(self):
		print("CheckoutBranch")

	def PushData(self):
		print("PushData")