from tkinter import * 
import tkinter as tk
from tkinter.ttk import *
from PIL import Image
from PIL import ImageTk
from tkinter import filedialog
import time
import MainWindow

class DisplayWindow(tk.Tk):

    def __init__(self, *args, **kwargs):
        
        tk.Tk.__init__(self, *args, **kwargs)
        self.geometry("400x300")
        self.configure(bg='#E0EFF9')

class newWin(tk.Frame):
    def __init__(self, parent):
        tk.Frame.__init__(self, parent)
    #self.parent = parent
        self.parent=tk.Toplevel(parent)
        self.parent.title("hellp")
        frame7 = tk.Frame(self.parent)
        self.parent.geometry("600x350")
        frame7.pack(fill=X)
        lbl7 = Label(frame7, text="Model Is Being Trainning", font=("",10))
        lbl7.pack( padx=30, pady=15)

        frame8 = tk.Frame(self.parent)
        frame8.pack(fill=X)
        self.brt = 100
        self.style = Style(frame8)
        self.style.layout('text.Horizontal.TProgressbar',
             [('Horizontal.Progressbar.trough',
               {'children': [('Horizontal.Progressbar.pbar',
                              {'side': 'left', 'sticky': 'ns'})],
                'sticky': 'nswe'}),
              ('Horizontal.Progressbar.label', {'sticky': 'ns'})])
              # , lightcolor=None, bordercolo=None, darkcolor=None
        self.style.configure('text.Horizontal.TProgressbar', text='0 %')
## Progress bar widget 
        self.progressBar = Progressbar(frame8,length=200,
                              maximum=self.brt, value=0,style='text.Horizontal.TProgressbar') 
        self.progressBar.pack(pady = 10)
        self.bar()




    def bar(self):
       global barProgress
       barProgress = 0
       self.progressBar['value'] = barProgress
       self.parent.after(500, self.updatebar)
   
    def updatebar(self):
       global barProgress
       if(barProgress<self.brt):
           barProgress +=20
           self.progressBar['value'] = barProgress
           self.style.configure('text.Horizontal.TProgressbar',
                           text='{:g} %'.format(barProgress))
           self.parent.after(500,self.updatebar)

if __name__ == "__main__":
    
    app = DisplayWindow()
    a=newWin(app)


    app.mainloop()