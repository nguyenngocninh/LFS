# importing tkinter module 
from tkinter import * 
from tkinter.ttk import *
import time


# creating tkinter window 
root = Tk() 
brt = 100
style = Style(root)
style.layout('text.Horizontal.TProgressbar',
             [('Horizontal.Progressbar.trough',
               {'children': [('Horizontal.Progressbar.pbar',
                              {'side': 'left', 'sticky': 'ns'})],
                'sticky': 'nswe'}),
              ('Horizontal.Progressbar.label', {'sticky': 'ns'})])
              # , lightcolor=None, bordercolo=None, darkcolor=None
style.configure('text.Horizontal.TProgressbar', text='0 %')
# Progress bar widget 
progressBar = Progressbar(root,length=200,
                              maximum=brt, value=0,style='text.Horizontal.TProgressbar') 
progressBar.pack(pady = 10) 



# Function responsible for the updation 
# of the progress bar value 
def bar():
	global barProgress
	barProgress = 0
	progressBar['value'] = barProgress
	root.after(500, updatebar)

def updatebar():
	global barProgress
	if(barProgress<brt):
		barProgress +=20
		progressBar['value'] = barProgress
		style.configure('text.Horizontal.TProgressbar',
                        text='{:g} %'.format(barProgress))
		root.after(500,updatebar)
  
# This button will initialize 
# the progress bar 
Button(root, text = 'Start', command = bar).pack(pady = 10) 
  
# infinite loop 
mainloop() 