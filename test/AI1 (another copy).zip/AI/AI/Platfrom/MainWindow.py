from tkinter import * 
import tkinter as tk
from tkinter.ttk import *
from PIL import Image
from PIL import ImageTk

import TransferLearningWindow
import DatasetManagement
import TrainedModel

class MainWindow(tk.Frame):
    def __init__(self, parent, controller):
        tk.Frame.__init__(self,parent)
        self.parent = parent
        global photoImg
        global gui_elements
        self.configure(bg='#E0EFF9')
        frame = tk.Frame(self,bg='#E0EFF9')
        frame.pack(side = LEFT,fill=BOTH, expand=True)


        load = Image.open("./4x.PNG")
        #load = load.resize((300,350), Image.ANTIALIAS)
        render = ImageTk.PhotoImage(load)

        img0 = tk.Label(frame, image=render,bg='#E0EFF9')
        img0.image = render
        img0.pack(fill=BOTH, expand=True)



        img = Image.open("./123.png")
        img = img.resize((210,48), Image.ANTIALIAS)
        photoImg =  ImageTk.PhotoImage(img)


        buttonDataset= tk.Button(self, text = " Dataset Management" ,image = photoImg,
                                                fg="white", font=("",9,"bold"),compound = CENTER, height=35, width=180)
        buttonDataset.pack(side = TOP, anchor = 'ne',padx=30,pady=40) 
        buttonDataset['command'] = lambda: controller.show_frame(DatasetManagement.ManageDataset)  

        buttonTransLearning = tk.Button(self, text = "  Transfer Learning" ,image = photoImg,
                                      fg="white", font=("",9,"bold"),compound = CENTER, height=35, width=180)
        buttonTransLearning.pack(side = TOP, anchor = 'ne',padx=30) 

        buttonTransLearning['command'] = lambda: controller.show_frame(TransferLearningWindow.TransferLearningWindow)  

        buttonTraniedModel= tk.Button(self, text = "  Trained Model\n   Management" ,image = photoImg,
                                fg="white", font=("",9,"bold"),compound = CENTER, height=35, width=180)
        buttonTraniedModel.pack(side = TOP, anchor = 'ne',padx=30,pady=40) 

        buttonTraniedModel['command'] = lambda: controller.show_frame(TrainedModel.TrainedModel)  
