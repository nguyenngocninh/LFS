from tkinter import * 
import tkinter as tk
from tkinter.ttk import *
from PIL import Image
from PIL import ImageTk
from tkinter import filedialog
import time
import MainWindow

class TransferLearningWindow(tk.Frame): 
	def __init__(self, parent, controller):
		tk.Frame.__init__(self,parent)
		self.parent = parent
		self.configure(bg='#C3E0FF')


		frame4 = tk.Frame(self,bg='#C3E0FF')
		frame4.pack(side = TOP,fill=BOTH, expand = True)

		load = Image.open("./5x.PNG")
		#load = load.resize((216,250), Image.ANTIALIAS)
		render = ImageTk.PhotoImage(load)
	
		img0 = tk.Label(frame4, image=render,bg='#C3E0FF')
		img0.image = render
		img0.pack(fill= Y,side = LEFT, anchor = 'nw',padx=40,pady=40)
	
		load = Image.open("./6x.PNG")
		#load = load.resize((216,250), Image.ANTIALIAS)
		render = ImageTk.PhotoImage(load)

		img1 = tk.Label(frame4, image=render,bg='#C3E0FF')
		img1.image = render
		img1.pack(fill= Y,side = RIGHT, anchor = 'ne',padx=40,pady=40)

		frame5 = tk.Frame(self,bg='#C3E0FF')
		frame5.pack(side = BOTTOM,fill=BOTH, expand = True)

		buttonBackMain= tk.Button(frame5, text = "Back",bg='#FEEAD4')
		buttonBackMain.pack(side = BOTTOM, anchor = 'sw',padx=10,pady=10) 
		buttonBackMain['command'] = lambda: controller.show_frame(MainWindow.MainWindow)	

	def CreateMenuBar(self,controller):

			menubar = tk.Menu(controller,bg='#FEEAD4', font=("",9,"bold") )
	
			objectDetection = tk.Menu(menubar, tearoff=0, bg='white')
			objectDetection.add_command(label="Train" )
			objectDetection.add_command(label="Evaluate")
			objectDetection.add_command(label="Interference")
			objectDetection.add_command(label="Prune")
	
			menubar.add_cascade(label="ObjectDetection", menu=objectDetection)

			Segmentation = tk.Menu(menubar, tearoff=0, bg='white')
			Segmentation.add_command(label="Train", command = lambda: controller.show_frame(TrainModel))
			Segmentation.add_command(label="Evaluate")
			Segmentation.add_command(label="Interference")
			Segmentation.add_command(label="Prune")

			menubar.add_cascade(label="Segmentation", menu=Segmentation)

			return menubar
	

class TrainModel(TransferLearningWindow):
	def __init__(self, parent, controller):
		tk.Frame.__init__(self,parent)
		self.parent = parent
		#self.configure(bg='#C3E0FF')
		self.folder_path =  tk.StringVar()
		frame0 = tk.Frame(self)
		frame0.pack(fill=X)
  	
		lbl0 = Label(frame0, text="Genneral Configuration",font =("",10,'bold'))
		lbl0.pack(side=LEFT, padx=30, pady=10)

		frame1 = tk.Frame(self)
		frame1.pack(fill=X)
		lbl1 = Label(frame1, text="Architectures Model", width=19, font=("",10))
		lbl1.pack(side=LEFT, padx=30, pady=15)
		#entry1 = Entry(frame1, width = 37, font=("",10))
		#entry1.pack(side=LEFT,pady=15)

		self.value = tk.StringVar() 
		monthchoosen = ttk.Combobox(frame1, width = 37, textvariable = self.value) 
  
		# Adding combobox drop down list 
		monthchoosen["values"] = ("MaskRCNN",  
                        		  "UNet")

		monthchoosen.pack(side=LEFT,pady=15)
		monthchoosen.current(0) 
		frame2 = tk.Frame(self)
		frame2.pack(fill=X)
		lbl2 = Label(frame2, text="Output folder", width=19, font=("",10))
		lbl2.pack(side=LEFT, padx=30, pady=15)

		self.OutputFolderValue = tk.StringVar() 
		OutputFolder = ttk.Combobox(frame2, width = 37, textvariable = self.OutputFolderValue)
  
		# Adding combobox drop down list 
		OutputFolder["values"] = ("...")
		OutputFolder.bind('<<ComboboxSelected>>', self.OutputFolderCallback)
		OutputFolder.pack(side=LEFT,pady=15)


		frame30 = tk.Frame(self)
		frame30.pack(fill=X)
		lbl30 = Label(frame30, text="Output Model Name", width=19, font=("",10))
		lbl30.pack(side=LEFT, padx=30, pady=15)
		entry30 = Entry(frame30, width = 38, font=("",10))
		entry30.pack(side=LEFT,pady=15)


		frame3 = tk.Frame(self)
		frame3.pack(fill=X)
		lbl3 = Label(frame3, text="Pretrained Model", width=19, font=("",10))
		lbl3.pack(side=LEFT, padx=30, pady=15)

		self.preTrainedModelValue = tk.StringVar() 
		pretrainedModel = ttk.Combobox(frame3, width = 37, textvariable = self.preTrainedModelValue)
  
		# Adding combobox drop down list 
		pretrainedModel["values"] = ("Not use",  
                        		  "PrePytorch",
                        		  "...")
		pretrainedModel.bind('<<ComboboxSelected>>', self.PreModelCallback)
		pretrainedModel.pack(side=LEFT,pady=15)
		pretrainedModel.current(0) 


		frame4 = tk.Frame(self)
		frame4.pack(fill=X)
		lbl4 = Label(frame4, text="Number GPUS", width=19, font=("",10))
		lbl4.pack(side=LEFT, padx=30, pady=15)
		entry4 = Entry(frame4, width = 38, font=("",10))
		entry4.pack(side=LEFT,pady=15)

		frame5 = tk.Frame(self)
		frame5.pack(fill=BOTH, expand = True)

		buttonBackMain= tk.Button(frame5, text = "Back",bg='#FEEAD4')
		buttonBackMain.pack(side = LEFT, anchor = 'sw',padx=10,pady=10) 
		buttonBackMain['command'] = lambda: controller.show_frame(MainWindow.MainWindow)	

		buttonBackMain1= tk.Button(frame5, text = "Next",bg='#FEEAD4')
		buttonBackMain1.pack(side = RIGHT, anchor = 'se',padx=10,pady=10) 
		buttonBackMain1['command'] = lambda: controller.show_frame(SpecModelConfig)

	def PreModelCallback(self, event=None):
		if (self.preTrainedModelValue.get() == "..."):
			print("OK\n")
			name= filedialog.askopenfilename(title = "Select Model File",filetypes = (("Pytorch Model",
                                                        "*.pth*"),("All files","*.*")))
			self.preTrainedModelValue.set(name)

	def CreateMenuBar(self,controller):
		super().CreateMenuBar(controller)

	def OutputFolderCallback(self,event=None):
    # Allow user to select a directory and store it in global var
    # called folder_path
		filename = filedialog.askdirectory()
		self.OutputFolderValue.set(filename)

class SpecModelConfig(TransferLearningWindow):
	def __init__(self, parent, controller):
		tk.Frame.__init__(self,parent)
		self.parent = parent
		#self.configure(bg='#C3E0FF')
		self.folder_path =  tk.StringVar()
		frame0 = tk.Frame(self)
		frame0.pack(fill=X)
  	
		lbl0 = Label(frame0, text="MaskRCNN Configuration",font =("",10,'bold'))
		lbl0.pack(side=LEFT, padx=30, pady=10)

		frame4 = tk.Frame(self)
		frame4.pack(fill=X)
		lbl4 = Label(frame4, text="Number layers", width=19, font=("",10))
		lbl4.pack(side=LEFT, padx=30, pady=15)
		entry4 = Entry(frame4, width = 38, font=("",10))
		entry4.pack(side=LEFT,pady=15)


		frame5 = tk.Frame(self)
		frame5.pack(fill=X)
		lbl5 = Label(frame5, text="Architecture", width=19, font=("",10))
		lbl5.pack(side=LEFT, padx=30, pady=15)
		entry5 = Entry(frame5, width = 38, font=("",10))
		entry5.pack(side=LEFT,pady=15)

		frame6 = tk.Frame(self)
		frame6.pack(fill=X)
		lbl6 = Label(frame6, text="Mask size", width=19, font=("",10))
		lbl6.pack(side=LEFT, padx=30, pady=15)
		entry6 = Entry(frame6, width = 38, font=("",10))
		entry6.pack(side=LEFT,pady=15)

		frame7 = tk.Frame(self)
		frame7.pack(fill=X)
		lbl7 = Label(frame7, text="Batch size", width=19, font=("",10))
		lbl7.pack(side=LEFT, padx=30, pady=15)
		entry7 = Entry(frame7, width = 38, font=("",10))
		entry7.pack(side=LEFT,pady=15)

		frame8 = tk.Frame(self)
		frame8.pack(fill=X)
		lbl8 = Label(frame8, text="epochs ", width=19, font=("",10))
		lbl8.pack(side=LEFT, padx=30, pady=15)
		entry8 = Entry(frame8, width = 38, font=("",10))
		entry8.pack(side=LEFT,pady=15)

		frame10 = tk.Frame(self)
		frame10.pack(fill=BOTH, expand = True)


		buttonBackTrain= tk.Button(frame10, text = "Back",bg='#FEEAD4')
		buttonBackTrain.pack(side = LEFT, anchor = 'sw',padx=10,pady=10) 
		buttonBackTrain['command'] = lambda: controller.show_frame(TrainModel)	

		ButtonTrainning= tk.Button(frame10, text = "OK",bg='#FEEAD4')
		ButtonTrainning.pack(side = RIGHT, anchor = 'se',padx=10,pady=10) 
		ButtonTrainning['command'] = lambda: ProgressTrainning(controller)

	def CreateMenuBar(self,controller):
		super().CreateMenuBar(controller)


class ProgressTrainning(tk.Frame):
	def __init__(self, controller):
		tk.Frame.__init__(self, controller)
		self.controller = Toplevel(controller) 
		self.controller.title("Trainning Model") 
		windowWidth = 600
		windowHeight = 350
 
		# Gets both half the screen width/height and window width/height
		positionRight = int(self.controller.winfo_screenwidth()/2 - windowWidth/2)
		positionDown = int(self.controller.winfo_screenheight()/2 - windowHeight/2)
		self.controller.geometry("%dx%d+%d+%d"%(windowWidth,windowHeight,positionRight, positionDown))

		frame7 = tk.Frame(self.controller)
		frame7.pack(fill=X)
		lbl7 = Label(frame7, text="Model Is Being Trainning", font=("",10))
		lbl7.pack( padx=30, pady=15)

		frame8 = tk.Frame(self.controller)
		frame8.pack(fill=X)
		self.brt = 100
		self.style = Style(frame8)
		self.style.layout('text.Horizontal.TProgressbar',
             [('Horizontal.Progressbar.trough',
               {'children': [('Horizontal.Progressbar.pbar',
                              {'side': 'left', 'sticky': 'ns'})],
                'sticky': 'nswe'}),
              ('Horizontal.Progressbar.label', {'sticky': 'ns'})])
              # , lightcolor=None, bordercolo=None, darkcolor=None
		self.style.configure('text.Horizontal.TProgressbar', text='0 %')
## Progress bar widget 
		self.progressBar = Progressbar(frame8,length=200,
                              maximum=self.brt, value=0,style='text.Horizontal.TProgressbar') 
		self.progressBar.pack(pady = 10)
		self.bar()



# Function responsible for the updation 
# of the progress bar value 
	def bar(self):
		global barProgress
		barProgress = 0
		self.progressBar['value'] = barProgress
		self.controller.after(500, self.updatebar)
	
	def updatebar(self):
		global barProgress
		if(barProgress<self.brt):
			barProgress +=20
			self.progressBar['value'] = barProgress
			self.style.configure('text.Horizontal.TProgressbar',
	                        text='{:g} %'.format(barProgress))
			self.controller.after(500,self.updatebar)
		else:
			frame7 = tk.Frame(self.controller)
			frame7.pack(fill=X)
			buttonBackTrainx= tk.Button(frame7, text = "Ok",bg='#FEEAD4',command=self.controller.destroy)
			buttonBackTrainx.pack() 


