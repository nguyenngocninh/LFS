import tkinter as tk


class Win:
    def __init__(self, root):
        """Define window for the app"""
        self.root = root
        self.root.geometry("400x300")
        self.root["bg"] = "coral"
        self.button_rename = tk.Button(self.root, text = "New window",
            command= lambda: self.new_window(Win2)).pack()

    def new_window(self, _class):
        self.new = tk.Toplevel(self.root)
        _class(self.new)

class Win2:
    def __init__(self, root):
        self.root = root
        self.root.geometry("300x300+200+200")
        self.root["bg"] = "navy"
        
    def bar(self):
       global barProgress
       barProgress = 0
       self.parent.after(500, self.updatebar)
   
    def updatebar(self):
       global barProgress
       if(barProgress<5):
           barProgress +=1
           self.parent.after(500,updatebar)


if __name__ == "__main__":
    root = tk.Tk()
    app = Win(root)
    app.root.title("Lezioni")
    root.mainloop()