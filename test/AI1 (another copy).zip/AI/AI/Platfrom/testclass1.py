from testclass import test

class test1():
 	def __init__(self):
 		print("hello1\n")