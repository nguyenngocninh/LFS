from tkinter import * 
import tkinter as tk
from tkinter.ttk import *
from PIL import Image
from PIL import ImageTk

from DisplayWindow import DisplayWindow


def main():
	app = DisplayWindow()
	app.mainloop()

if __name__ == '__main__':
	main()